Place JDBC drivers' JAR files in this directory to make them available to BIRT.
